THIS IS THE PROGRAM IN THE ROM.

the code is written with most significant bit at the left, 
least significant at the right. lastly
code is written sequentially, meaning that the instruction
'e4' is placed at address 0, '01' placed at address 1, and so on.


this is the code in hex

e0 01 e4 _0f_ 84 0c 2b 00 34 00 ff 04 ff 0c

this is the code in bin

11100000 00000001 11100100 _00001111_ 10000100 00001100 00101011 00000000 00110100 00000000 11111111 00000100 11111111 00001100


Note: 0f in the number in RAM which we are multiplying by. It can be changed to any other number and it will be multiplied by the number in the keypad.